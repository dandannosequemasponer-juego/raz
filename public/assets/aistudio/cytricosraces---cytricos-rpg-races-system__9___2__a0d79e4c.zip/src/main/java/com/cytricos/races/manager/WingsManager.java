package com.cytricos.races.manager;

import com.cytricos.races.CytricosRaces;
import com.cytricos.races.model.PlayerData;
import com.cytricos.races.util.ColorUtils;
import org.bukkit.*;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.components.EquippableComponent;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Transformation;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Gestor Independiente de Alas Cosméticas 3D Animadas para CYTRICOS RPG (v7.0.0).
 * 100% gratuito e independiente (NO requiere ItemsAdder, Oraxen ni mods cliente).
 *
 * Implementación compatible con Paper 26.2:
 * 1) Élitros Físicos Personalizados con EquippableComponent (slot CHEST + textura 64x32 propia)
 *    y modelos Blockbench duales (CustomModelData 200xx).
 * 2) Rig Ligero Dual-Hinge mediante 2 entidades pasajeras ItemDisplay no persistentes
 *    (_left CMD 201xx y _right CMD 202xx) con pivote en el hombro e interpolación nativa:
 *    - IDLE: respiración y balanceo orgánico suave.
 *    - OPENING: despliegue amplio al equipar o iniciar vuelo.
 *    - CLOSING: repliegue elegante tras aterrizar o envainar.
 *    - FLYING: aleteo energético sincronizado con la velocidad/movimiento.
 *    - GLIDING: ángulo aerodinámico en V durante planeo con Élitros.
 *
 * Limitación técnica documentada: Java Edition vanilla sin OptiFine/EMF/mods no permite
 * esqueletos multi-articulados por pluma en la espalda; la animación real por bisagra en
 * hombro izquierdo/derecho mediante ItemDisplay logra movimiento fluido interpolado sin lag.
 *
 * Lead Developers: Dandan_13 & Wolfit12
 */
public class WingsManager {
    private final CytricosRaces plugin;
    private final NamespacedKey wingKey;
    private final NamespacedKey displayTagKey;
    private final Map<String, WingDefinition> registry = new LinkedHashMap<>();
    private final Map<UUID, WingRig> activeRigs = new ConcurrentHashMap<>();
    private BukkitTask syncTask;
    private long animationTick = 0L;

    public enum WingRarity {
        COMUN("&7Común", "&7"),
        RARO("&9Raro", "&9"),
        EPICO("&5Épico", "&5"),
        LEGENDARIO("&6Legendario", "&6"),
        MITICO("&d&lMítico", "&d");

        public final String label;
        public final String colorCode;

        WingRarity(String label, String colorCode) {
            this.label = label;
            this.colorCode = colorCode;
        }
    }

    public enum WingState {
        IDLE("Reposo"),
        OPENING("Desplegando"),
        CLOSING("Replegando"),
        FLYING("Aleteo"),
        GLIDING("Planeo");

        public final String displayEs;

        WingState(String displayEs) {
            this.displayEs = displayEs;
        }
    }

    public static class WingDefinition {
        public final String id;
        public final String displayName;
        public final String description;
        public final int customModelData;
        public final int leftModelData;
        public final int rightModelData;
        public final Material iconMaterial;
        public final Particle trailParticle;
        public final String recommendedRace;
        public final WingRarity rarity;
        public final int requiredLevel;
        public final double unlockCost;
        public final String unlockNote;
        public final float scale;

        public WingDefinition(String id, String displayName, String description,
                              int customModelData, int leftModelData, int rightModelData,
                              Material iconMaterial, Particle trailParticle, String recommendedRace,
                              WingRarity rarity, int requiredLevel, double unlockCost,
                              String unlockNote, float scale) {
            this.id = id;
            this.displayName = displayName;
            this.description = description;
            this.customModelData = customModelData;
            this.leftModelData = leftModelData;
            this.rightModelData = rightModelData;
            this.iconMaterial = iconMaterial;
            this.trailParticle = trailParticle;
            this.recommendedRace = recommendedRace;
            this.rarity = rarity;
            this.requiredLevel = requiredLevel;
            this.unlockCost = unlockCost;
            this.unlockNote = unlockNote;
            this.scale = scale;
        }
    }

    private static class WingRig {
        final String wingId;
        final ItemDisplay leftDisplay;
        final ItemDisplay rightDisplay;
        WingState currentState = WingState.OPENING;
        int transitionTicksLeft = 10;
        boolean wasAirborne = false;

        WingRig(String wingId, ItemDisplay leftDisplay, ItemDisplay rightDisplay) {
            this.wingId = wingId;
            this.leftDisplay = leftDisplay;
            this.rightDisplay = rightDisplay;
        }

        boolean isValid() {
            return leftDisplay != null && !leftDisplay.isDead()
                    && rightDisplay != null && !rightDisplay.isDead();
        }
    }

    public WingsManager(CytricosRaces plugin) {
        this.plugin = plugin;
        this.wingKey = new NamespacedKey(plugin, "cytricos_wing_id");
        this.displayTagKey = new NamespacedKey(plugin, "cytricos_wing_display");
        initWings();
    }

    private void initWings() {
        register(new WingDefinition(
                "angel_wings", "&f&lAlas de Ángel",
                "Plumas radiantes forjadas con luz divina serafín.",
                20001, 20101, 20201,
                Material.FEATHER, Particle.END_ROD, "angel",
                WingRarity.EPICO, 1, 0.0,
                "Disponible gratis desde Nivel 1", 1.15f
        ));
        register(new WingDefinition(
                "dark_angel_wings", "&5&lAlas de Ángel Caído",
                "Plumaje sombrío de obsidiana con filo carmesí crepuscular.",
                20009, 20109, 20209,
                Material.OBSIDIAN, Particle.REVERSE_PORTAL, "angel",
                WingRarity.LEGENDARIO, 3, 7500.0,
                "Nivel 3+ o 7,500$ en Vault", 1.22f
        ));
        register(new WingDefinition(
                "demon_wings", "&c&lAlas de Demonio",
                "Alas membranosas negras con vetas ardientes de magma.",
                20002, 20102, 20202,
                Material.BLAZE_POWDER, Particle.FLAME, "demon",
                WingRarity.EPICO, 2, 4000.0,
                "Nivel 2+ o 4,000$ en Vault", 1.18f
        ));
        register(new WingDefinition(
                "vampire_wings", "&4&lAlas de Vampiro",
                "Membranas carmesí nocturnas con espolones óseos.",
                20003, 20103, 20203,
                Material.REDSTONE, Particle.CRIMSON_SPORE, "vampire",
                WingRarity.RARO, 1, 0.0,
                "Disponible gratis desde Nivel 1", 1.12f
        ));
        register(new WingDefinition(
                "dragon_wings", "&5&lAlas de Dragón",
                "Envergadura escamosa dracónica con espinas de amatista.",
                20004, 20104, 20204,
                Material.DRAGON_BREATH, Particle.DRAGON_BREATH, "dragonkin",
                WingRarity.LEGENDARIO, 4, 10000.0,
                "Nivel 4+ o 10,000$ en Vault", 1.32f
        ));
        register(new WingDefinition(
                "fairy_wings", "&d&lAlas de Hada",
                "Alas translúcidas iridiscentes en cuatro pétalos feéricos.",
                20005, 20105, 20205,
                Material.PRISMARINE_CRYSTALS, Particle.CHERRY_LEAVES, "fairy",
                WingRarity.RARO, 1, 0.0,
                "Disponible gratis desde Nivel 1", 1.05f
        ));
        register(new WingDefinition(
                "phoenix_wings", "&6&lAlas de Fénix",
                "Plumaje solar viviente que irradia brasas eternas.",
                20006, 20106, 20206,
                Material.FIRE_CHARGE, Particle.LAVA, "demon",
                WingRarity.MITICO, 4, 15000.0,
                "Nivel 4+ o 15,000$ en Vault", 1.25f
        ));
        register(new WingDefinition(
                "celestial_wings", "&b&lAlas Celestiales",
                "Alas astrales cristalinas entretejidas con constelaciones.",
                20008, 20108, 20208,
                Material.NETHER_STAR, Particle.GLOW, "angel",
                WingRarity.MITICO, 5, 18000.0,
                "Nivel 5+ o 18,000$ en Vault", 1.24f
        ));
        register(new WingDefinition(
                "void_wings", "&3&lAlas del Vacío",
                "Segmentos gravitacionales oscuros suspendidos por energía del End.",
                20010, 20110, 20210,
                Material.ECHO_SHARD, Particle.PORTAL, "undead",
                WingRarity.MITICO, 5, 20000.0,
                "Nivel 5+ o 20,000$ en Vault", 1.26f
        ));
        register(new WingDefinition(
                "nature_wings", "&a&lAlas de Naturaleza",
                "Hojas esmeralda y lianas floridas bendecidas por el bosque.",
                20011, 20111, 20211,
                Material.SPORE_BLOSSOM, Particle.HAPPY_VILLAGER, "druid",
                WingRarity.EPICO, 2, 3500.0,
                "Nivel 2+ o 3,500$ en Vault", 1.14f
        ));
        register(new WingDefinition(
                "dark_wings", "&8&lAlas Sombrías Clásicas",
                "Sombras etéreas tejidas con bruma espectral nocturna.",
                20007, 20107, 20207,
                Material.COAL, Particle.SMOKE, "undead",
                WingRarity.RARO, 1, 0.0,
                "Disponible gratis desde Nivel 1", 1.12f
        ));
    }

    private void register(WingDefinition def) {
        registry.put(def.id.toLowerCase(), def);
    }

    public Collection<WingDefinition> getAllWings() {
        return Collections.unmodifiableCollection(registry.values());
    }

    public WingDefinition getWing(String id) {
        if (id == null) return null;
        return registry.get(id.toLowerCase());
    }

    public boolean isWingUnlocked(Player player, PlayerData data, WingDefinition def) {
        if (def == null) return false;
        if (player != null && (player.hasPermission("cytricosraces.admin")
                || player.hasPermission("cytricosraces.wings." + def.id)
                || player.hasPermission("cytricosraces.wings.*"))) {
            return true;
        }
        if (def.requiredLevel <= 1 && def.unlockCost <= 0.0) {
            return true;
        }
        if (data == null) return false;
        if (data.hasUnlockedCosmetic("wing:" + def.id)) {
            return true;
        }
        if (def.id.equalsIgnoreCase(data.getSelectedWings())) {
            return true;
        }
        if (data.getLevel() >= def.requiredLevel) {
            return true;
        }
        return false;
    }

    public boolean tryUnlockWithVault(Player player, PlayerData data, WingDefinition def) {
        if (player == null || data == null || def == null) return false;
        if (isWingUnlocked(player, data, def)) return true;

        if (!plugin.getConfig().getBoolean("cosmetics_settings.wings.allow_vault_unlock", true)) {
            ColorUtils.sendMessage(player, "&cRequiere &eNivel " + def.requiredLevel + "+ &cpara desbloquear estas alas.");
            return false;
        }
        if (!plugin.isVaultAvailable() || plugin.getVaultEconomy() == null || def.unlockCost <= 0.0) {
            ColorUtils.sendMessage(player, "&cRequiere &eNivel " + def.requiredLevel + "+ &cpara desbloquear " + def.displayName + "&c.");
            return false;
        }

        double balance = plugin.getVaultEconomy().getBalance(player);
        if (balance < def.unlockCost) {
            ColorUtils.sendMessage(player, "&cNecesitas &e$" + String.format("%.0f", def.unlockCost)
                    + " &co alcanzar el &eNivel " + def.requiredLevel + " &cpara desbloquear " + def.displayName + "&c.");
            return false;
        }

        plugin.getVaultEconomy().withdrawPlayer(player, def.unlockCost);
        data.unlockCosmetic("wing:" + def.id);
        plugin.getPlayerDataManager().saveToFile(data);
        ColorUtils.sendMessage(player, "&a&l[COSMÉTICOS] &7¡Has desbloqueado " + def.displayName + " &7por &e$" + String.format("%.0f", def.unlockCost) + "&7!");
        return true;
    }

    /**
     * Construye un objeto ELYTRA físico cosmético con EquippableComponent nativo (Paper 26.2),
     * CustomModelData dual y clave PDC anti-falsificación.
     */
    public ItemStack createWingElytraItem(String wingId) {
        WingDefinition def = getWing(wingId);
        if (def == null) return null;

        ItemStack item = new ItemStack(Material.ELYTRA);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.displayName(ColorUtils.component(def.displayName));
            meta.setCustomModelData(def.customModelData);
            try {
                EquippableComponent eq = meta.getEquippable();
                eq.setSlot(EquipmentSlot.CHEST);
                eq.setModel(new NamespacedKey("cytricos", def.id));
                meta.setEquippable(eq);
            } catch (Throwable ignored) {
                // Compatibilidad si un servidor derivado carece de EquippableComponent
            }

            meta.lore(ColorUtils.componentList(List.of(
                    "&7" + def.description,
                    "&7Rareza: " + def.rarity.label + " &8| &7Raza afín: &e" + def.recommendedRace.toUpperCase(),
                    "",
                    "&8Modelo Pack: &fcytricos:" + def.id + " &7(CMD " + def.customModelData + ")",
                    "&6&lCosmético Independiente CYTRICOS RPG",
                    "&7Equípalas en el pecho para planear con textura 64x32 propia."
            )));
            meta.getPersistentDataContainer().set(wingKey, PersistentDataType.STRING, def.id);
            meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS);
            item.setItemMeta(meta);
        }
        return item;
    }

    public boolean isWingItem(ItemStack item) {
        if (item == null || item.getType() == Material.AIR) return false;
        ItemMeta meta = item.getItemMeta();
        return meta != null && meta.getPersistentDataContainer().has(wingKey, PersistentDataType.STRING);
    }

    public String getWingIdFromItem(ItemStack item) {
        if (!isWingItem(item)) return null;
        return item.getItemMeta().getPersistentDataContainer().get(wingKey, PersistentDataType.STRING);
    }

    private ItemStack createWingPartStack(int customModelData) {
        ItemStack stack = new ItemStack(Material.FEATHER);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.setCustomModelData(customModelData);
            stack.setItemMeta(meta);
        }
        return stack;
    }

    public void equipCosmeticWings(Player player, String wingId) {
        removeWingDisplay(player);

        PlayerData data = plugin.getPlayerDataManager().get(player.getUniqueId());
        if (data == null) return;

        if (wingId == null || wingId.equalsIgnoreCase("none")) {
            data.setSelectedWings("none");
            plugin.getPlayerDataManager().saveToFile(data);
            return;
        }

        WingDefinition def = getWing(wingId);
        if (def == null) return;

        data.setSelectedWings(def.id);
        data.unlockCosmetic("wing:" + def.id);
        plugin.getPlayerDataManager().saveToFile(data);

        if (!plugin.getConfig().getBoolean("cosmetics_settings.wings.enabled", true)) {
            return;
        }
        if (!plugin.getConfig().getBoolean("cosmetics_settings.wings.use_display_entities", true)) {
            return;
        }

        spawnWingDisplay(player, def);
    }

    public void spawnWingDisplay(Player player, WingDefinition def) {
        if (player == null || !player.isOnline() || player.isDead() || def == null) return;
        removeWingDisplay(player);

        if (player.getGameMode() == GameMode.SPECTATOR || player.isInvisible()) {
            return;
        }

        int interpTicks = Math.max(1, plugin.getConfig().getInt("cosmetics_settings.wings.animation_period_ticks", 2));
        try {
            Location spawnLoc = player.getLocation();
            ItemDisplay leftDisplay = spawnHingeEntity(player, spawnLoc, def.leftModelData, interpTicks);
            ItemDisplay rightDisplay = spawnHingeEntity(player, spawnLoc, def.rightModelData, interpTicks);

            player.addPassenger(leftDisplay);
            player.addPassenger(rightDisplay);

            WingRig rig = new WingRig(def.id, leftDisplay, rightDisplay);
            rig.currentState = WingState.OPENING;
            rig.transitionTicksLeft = 10;
            activeRigs.put(player.getUniqueId(), rig);
            applyRigPose(player, def, rig, interpTicks);
        } catch (Throwable t) {
            plugin.getLogger().warning("No se pudo generar rig ItemDisplay para alas de " + player.getName() + ": " + t.getMessage());
        }
    }

    private ItemDisplay spawnHingeEntity(Player owner, Location loc, int modelData, int interpTicks) {
        return owner.getWorld().spawn(loc, ItemDisplay.class, entity -> {
            entity.setPersistent(false);
            entity.setItemStack(createWingPartStack(modelData));
            entity.setBillboard(Display.Billboard.FIXED);
            entity.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.FIXED);
            entity.setInterpolationDelay(0);
            entity.setInterpolationDuration(interpTicks);
            entity.setTeleportDuration(1);
            entity.setViewRange(0.85f);
            entity.getPersistentDataContainer().set(displayTagKey, PersistentDataType.STRING, owner.getUniqueId().toString());
        });
    }

    public void removeWingDisplay(Player player) {
        if (player == null) return;
        WingRig existing = activeRigs.remove(player.getUniqueId());
        if (existing != null) {
            if (existing.leftDisplay != null && !existing.leftDisplay.isDead()) {
                existing.leftDisplay.remove();
            }
            if (existing.rightDisplay != null && !existing.rightDisplay.isDead()) {
                existing.rightDisplay.remove();
            }
        }
        String ownerStr = player.getUniqueId().toString();
        for (Entity passenger : new ArrayList<>(player.getPassengers())) {
            if (passenger instanceof ItemDisplay id && (
                    !id.isPersistent() || ownerStr.equals(id.getPersistentDataContainer().get(displayTagKey, PersistentDataType.STRING))
            )) {
                id.remove();
            }
        }
    }

    public void refreshPlayerWings(Player player) {
        if (player == null || !player.isOnline()) return;
        PlayerData data = plugin.getPlayerDataManager().get(player.getUniqueId());
        if (data == null) return;
        String wingId = data.getSelectedWings();
        if (wingId != null && !wingId.equalsIgnoreCase("none")
                && plugin.getConfig().getBoolean("cosmetics_settings.wings.enabled", true)
                && plugin.getConfig().getBoolean("cosmetics_settings.wings.use_display_entities", true)) {
            WingDefinition def = getWing(wingId);
            if (def != null) {
                spawnWingDisplay(player, def);
                return;
            }
        }
        removeWingDisplay(player);
    }

    public void startSyncTask() {
        stopSyncTask();
        purgeOrphanedWingEntities();
        if (!plugin.getConfig().getBoolean("cosmetics_settings.wings.enabled", true)) return;

        int period = Math.max(1, plugin.getConfig().getInt("cosmetics_settings.wings.animation_period_ticks", 2));
        syncTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            animationTick += period;
            boolean globalParticles = plugin.getConfig().getBoolean("cosmetics_settings.wings.particles_enabled", true);

            Iterator<Map.Entry<UUID, WingRig>> it = activeRigs.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<UUID, WingRig> entry = it.next();
                Player player = Bukkit.getPlayer(entry.getKey());
                WingRig rig = entry.getValue();

                if (player == null || !player.isOnline() || player.isDead() || rig == null || !rig.isValid()) {
                    despawnRig(rig);
                    it.remove();
                    continue;
                }

                if (player.isInvisible() || player.getGameMode() == GameMode.SPECTATOR) {
                    despawnRig(rig);
                    it.remove();
                    continue;
                }

                WingDefinition def = getWing(rig.wingId);
                if (def == null) {
                    despawnRig(rig);
                    it.remove();
                    continue;
                }

                // Reacoplar si algún teletransporte dentro del mismo mundo desmontó al pasajero
                if (!ensureMounted(player, rig.leftDisplay) || !ensureMounted(player, rig.rightDisplay)) {
                    despawnRig(rig);
                    it.remove();
                    continue;
                }

                updateRigState(player, rig, period);
                applyRigPose(player, def, rig, period);

                // Partículas ambientales sutiles en los extremos de las alas
                PlayerData data = plugin.getPlayerDataManager().get(player.getUniqueId());
                if (globalParticles && (data == null || data.isSettingParticles()) && def.trailParticle != null) {
                    double chance = (rig.currentState == WingState.FLYING || rig.currentState == WingState.GLIDING) ? 0.55 : 0.16;
                    if (Math.random() < chance) {
                        spawnWingTipParticles(player, def.trailParticle);
                    }
                }
            }
        }, 6L, period);
    }

    private boolean ensureMounted(Player player, ItemDisplay display) {
        if (!display.getWorld().equals(player.getWorld())) {
            return false;
        }
        if (!player.getPassengers().contains(display)) {
            return player.addPassenger(display);
        }
        return true;
    }

    private void updateRigState(Player player, WingRig rig, int elapsedTicks) {
        boolean isGliding = player.isGliding();
        boolean isFlying = player.isFlying();
        boolean isAirborne = isGliding || isFlying || (!player.isOnGround() && player.getVelocity().getY() < -0.15);

        if (isGliding) {
            rig.currentState = WingState.GLIDING;
            rig.wasAirborne = true;
            rig.transitionTicksLeft = 0;
            return;
        }

        if (isFlying || (isAirborne && player.getVelocity().lengthSquared() > 0.03)) {
            if (!rig.wasAirborne && rig.currentState != WingState.OPENING) {
                rig.currentState = WingState.OPENING;
                rig.transitionTicksLeft = 6;
            } else if (rig.transitionTicksLeft > 0) {
                rig.transitionTicksLeft = Math.max(0, rig.transitionTicksLeft - elapsedTicks);
            } else {
                rig.currentState = WingState.FLYING;
            }
            rig.wasAirborne = true;
            return;
        }

        // En tierra: si acaba de aterrizar, reproduce repliegue corto antes de volver a IDLE
        if (rig.wasAirborne) {
            rig.wasAirborne = false;
            rig.currentState = WingState.CLOSING;
            rig.transitionTicksLeft = 10;
            return;
        }

        if (rig.transitionTicksLeft > 0) {
            rig.transitionTicksLeft = Math.max(0, rig.transitionTicksLeft - elapsedTicks);
        } else {
            rig.currentState = WingState.IDLE;
        }
    }

    private void applyRigPose(Player player, WingDefinition def, WingRig rig, int interpTicks) {
        float bodyYaw = player.getLocation().getYaw();
        float bodyYawRad = (float) Math.toRadians(-bodyYaw);
        double timeSec = animationTick / 20.0;

        float flapDeg;
        float pitchDeg;
        float rollDeg;
        float sideSep = 0.14f;
        float backOffset = -0.22f;
        float verticalOffset = player.isSneaking() ? -0.44f : -0.26f;

        switch (rig.currentState) {
            case OPENING -> {
                float progress = 1.0f - Math.min(1.0f, rig.transitionTicksLeft / 10.0f);
                flapDeg = 68.0f - (50.0f * progress);
                pitchDeg = -8.0f * (1.0f - progress);
                rollDeg = 8.0f * progress;
            }
            case CLOSING -> {
                float progress = 1.0f - Math.min(1.0f, rig.transitionTicksLeft / 10.0f);
                flapDeg = 22.0f + (36.0f * progress);
                pitchDeg = 6.0f * progress;
                rollDeg = -4.0f * progress;
            }
            case FLYING -> {
                double beat = Math.sin(timeSec * 8.5);
                double secondary = Math.cos(timeSec * 8.5);
                flapDeg = (float) (32.0 + 24.0 * beat);
                pitchDeg = (float) (12.0 + 10.0 * secondary);
                rollDeg = (float) (8.0 * beat);
            }
            case GLIDING -> {
                double shimmer = Math.sin(timeSec * 5.0);
                flapDeg = (float) (40.0 + 6.0 * shimmer);
                pitchDeg = 32.0f;
                rollDeg = (float) (-6.0 + 3.0 * shimmer);
                verticalOffset = -0.35f;
                backOffset = -0.28f;
            }
            default -> {
                // IDLE: respiración orgánica suave (22..31 grados)
                double sway = Math.sin(timeSec * 2.4);
                boolean moving = player.getVelocity().setY(0).lengthSquared() > 0.008;
                double amp = moving ? 6.5 : 3.8;
                flapDeg = (float) (28.0 + amp * sway);
                pitchDeg = (float) (4.0 + 2.5 * Math.cos(timeSec * 2.4));
                rollDeg = (float) (2.5 * sway);
            }
        }

        float flapRad = (float) Math.toRadians(flapDeg);
        float pitchRad = (float) Math.toRadians(pitchDeg);
        float rollRad = (float) Math.toRadians(rollDeg);

        Quaternionf bodyQuat = new Quaternionf().rotateY(bodyYawRad);
        Vector3f scale = new Vector3f(def.scale, def.scale, def.scale);

        // Ala izquierda (+X local)
        Vector3f leftTrans = bodyQuat.transform(new Vector3f(sideSep, verticalOffset, backOffset), new Vector3f());
        Quaternionf leftLocal = new Quaternionf()
                .rotateY(+flapRad)
                .rotateX(pitchRad)
                .rotateZ(+rollRad);
        rig.leftDisplay.setInterpolationDelay(0);
        rig.leftDisplay.setInterpolationDuration(interpTicks);
        rig.leftDisplay.setTransformation(new Transformation(leftTrans, bodyQuat, scale, leftLocal));

        // Ala derecha (-X local)
        Vector3f rightTrans = bodyQuat.transform(new Vector3f(-sideSep, verticalOffset, backOffset), new Vector3f());
        Quaternionf rightLocal = new Quaternionf()
                .rotateY(-flapRad)
                .rotateX(pitchRad)
                .rotateZ(-rollRad);
        rig.rightDisplay.setInterpolationDelay(0);
        rig.rightDisplay.setInterpolationDuration(interpTicks);
        rig.rightDisplay.setTransformation(new Transformation(rightTrans, bodyQuat, scale, rightLocal));
    }

    private void spawnWingTipParticles(Player player, Particle particle) {
        Location base = player.getLocation().add(0, 1.15, 0);
        double rad = Math.toRadians(base.getYaw());
        double backX = Math.sin(rad) * 0.45;
        double backZ = -Math.cos(rad) * 0.45;
        double side = (Math.random() < 0.5 ? 1.0 : -1.0) * 0.68;
        double sideX = Math.cos(rad) * side;
        double sideZ = Math.sin(rad) * side;

        Location tip = base.add(backX + sideX, 0.15 + Math.random() * 0.35, backZ + sideZ);
        if (particle == Particle.LAVA) {
            player.getWorld().spawnParticle(Particle.FLAME, tip, 1, 0.08, 0.08, 0.08, 0.01);
        } else {
            player.getWorld().spawnParticle(particle, tip, 1, 0.08, 0.08, 0.08, 0.01);
        }
    }

    private void despawnRig(WingRig rig) {
        if (rig == null) return;
        if (rig.leftDisplay != null && !rig.leftDisplay.isDead()) {
            rig.leftDisplay.remove();
        }
        if (rig.rightDisplay != null && !rig.rightDisplay.isDead()) {
            rig.rightDisplay.remove();
        }
    }

    private void purgeOrphanedWingEntities() {
        for (World world : Bukkit.getWorlds()) {
            for (ItemDisplay display : world.getEntitiesByClass(ItemDisplay.class)) {
                if (display.getPersistentDataContainer().has(displayTagKey, PersistentDataType.STRING)) {
                    display.remove();
                }
            }
        }
    }

    public void stopSyncTask() {
        if (syncTask != null) {
            syncTask.cancel();
            syncTask = null;
        }
        cleanupAllDisplays();
    }

    public void cleanupAllDisplays() {
        for (WingRig rig : activeRigs.values()) {
            despawnRig(rig);
        }
        activeRigs.clear();
        purgeOrphanedWingEntities();
    }
}
