package com.cytricos.races.gui;

import com.cytricos.races.CytricosRaces;
import com.cytricos.races.manager.CosmeticsManager;
import com.cytricos.races.manager.WingsManager;
import com.cytricos.races.model.PlayerData;
import com.cytricos.races.util.ColorUtils;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Menú Renovado de Cosméticos, Colección, Rarezas, Auras y Alas 3D Animadas para CYTRICOS RPG.
 * Soporta pestañas (Alas 3D / Auras), paginación dinámica, filtro de desbloqueados,
 * desbloqueo por nivel o Vault, e inspección de modelos del Resource Pack independiente.
 *
 * Lead Developers: Dandan_13 & Wolfit12
 */
public class CosmeticsGUI {
    public static final String TITLE = ColorUtils.color("&8[&eCYTRICOS&8] &0Cosméticos y Alas 3D");
    public static final Component TITLE_COMPONENT = ColorUtils.component("&8[&eCYTRICOS&8] &0Cosméticos y Alas 3D");

    private static final int[] GRID_SLOTS = {
            19, 20, 21, 22, 23, 24, 25,
            28, 29, 30, 31, 32, 33, 34
    };

    private enum Tab {
        WINGS,
        AURAS
    }

    private static class ViewState {
        Tab tab = Tab.WINGS;
        int page = 0;
        boolean onlyUnlocked = false;
    }

    private final CytricosRaces plugin;
    private final Map<UUID, ViewState> viewStates = new ConcurrentHashMap<>();

    public CosmeticsGUI(CytricosRaces plugin) {
        this.plugin = plugin;
    }

    public void open(Player player) {
        ViewState state = viewStates.computeIfAbsent(player.getUniqueId(), k -> new ViewState());
        render(player, state);
    }

    private void render(Player player, ViewState state) {
        Inventory inv = Bukkit.createInventory(null, 54, TITLE_COMPONENT);

        ItemStack border = PlayerGUI.createGuiItem(Material.BLACK_STAINED_GLASS_PANE, " ", null);
        ItemStack subtle = PlayerGUI.createGuiItem(Material.GRAY_STAINED_GLASS_PANE, " ", null);
        for (int i = 0; i < 54; i++) {
            int row = i / 9;
            inv.setItem(i, (row == 0 || row == 5) ? border : subtle);
        }

        PlayerData data = plugin.getPlayerDataManager().get(player.getUniqueId());
        String activeAura = data != null ? data.getSelectedCosmeticAura().toLowerCase() : "none";
        String activeWings = data != null ? data.getSelectedWings().toLowerCase() : "none";

        List<WingsManager.WingDefinition> allWings = new ArrayList<>(plugin.getWingsManager().getAllWings());
        int unlockedWingsCount = 0;
        for (WingsManager.WingDefinition w : allWings) {
            if (plugin.getWingsManager().isWingUnlocked(player, data, w)) unlockedWingsCount++;
        }

        List<CosmeticsManager.AuraDefinition> allAuras = new ArrayList<>(plugin.getCosmeticsManager().getAllAuras());
        int unlockedAurasCount = 0;
        for (CosmeticsManager.AuraDefinition a : allAuras) {
            if (!"none".equalsIgnoreCase(a.id) && plugin.getCosmeticsManager().isAuraUnlocked(player, data, a)) {
                unlockedAurasCount++;
            }
        }

        // Barra superior (0-8): Pestañas, Filtro, Cabecera, Desequipar
        boolean onWings = state.tab == Tab.WINGS;
        inv.setItem(1, PlayerGUI.createGuiItem(Material.ELYTRA,
                (onWings ? "&a▶ " : "&7") + "&b&lAlas 3D Animadas",
                List.of(
                        "&7Colección desbloqueada: &e" + unlockedWingsCount + " / " + allWings.size(),
                        "&7Animaciones: &fReposo, Despliegue, Aleteo, Planeo",
                        "",
                        onWings ? "&a✔ Pestaña activa" : "&e▶ Clic para ver alas 3D"
                )));

        inv.setItem(3, PlayerGUI.createGuiItem(Material.COMPASS,
                "&e&lFiltro de Colección",
                List.of(
                        "&7Mostrando: " + (state.onlyUnlocked ? "&aSolo Desbloqueados" : "&fToda la Colección"),
                        "",
                        "&e▶ Clic para alternar filtro"
                )));

        String vaultInfo = plugin.isVaultAvailable() && plugin.getVaultEconomy() != null
                ? "&e$" + String.format("%.0f", plugin.getVaultEconomy().getBalance(player))
                : "&7No disponible";
        inv.setItem(4, PlayerGUI.createGuiItem(Material.AMETHYST_SHARD, "&d&lColección de Cosméticos", List.of(
                "&7Alas Equipadas: &b" + activeWings.toUpperCase(),
                "&7Aura Equipada: &e" + activeAura.toUpperCase(),
                "&7Tu Nivel Actual: &aNivel " + (data != null ? data.getLevel() : 1) + "/6",
                "&7Saldo Vault: " + vaultInfo,
                "&7Partículas: " + (data == null || data.isSettingParticles() ? "&aActivadas" : "&cDesactivadas"),
                "",
                "&8Sistema 100% independiente sin ItemsAdder ni Oraxen."
        )));

        inv.setItem(5, PlayerGUI.createGuiItem(Material.RED_DYE,
                onWings ? "&c&lDesequipar Alas Activas" : "&c&lDesequipar Aura Activa",
                List.of(onWings ? "&7Retira las alas animadas de tu espalda." : "&7Desactiva el aura de partículas orbital.")));

        inv.setItem(7, PlayerGUI.createGuiItem(Material.BLAZE_POWDER,
                (!onWings ? "&a▶ " : "&7") + "&6&lAuras de Partículas",
                List.of(
                        "&7Auras desbloqueadas: &e" + unlockedAurasCount + " / " + Math.max(1, allAuras.size() - 1),
                        "&7Efectos orbitales ligeros y configurables.",
                        "",
                        !onWings ? "&a✔ Pestaña activa" : "&e▶ Clic para ver auras"
                )));

        // Contenido paginado (14 slots)
        List<ItemStack> entries = onWings
                ? buildWingIcons(player, data, allWings, activeWings, state.onlyUnlocked)
                : buildAuraIcons(player, data, allAuras, activeAura, state.onlyUnlocked);

        int pageSize = GRID_SLOTS.length;
        int totalPages = Math.max(1, (int) Math.ceil(entries.size() / (double) pageSize));
        if (state.page >= totalPages) state.page = totalPages - 1;
        if (state.page < 0) state.page = 0;

        int start = state.page * pageSize;
        for (int i = 0; i < GRID_SLOTS.length; i++) {
            int dataIdx = start + i;
            if (dataIdx < entries.size()) {
                inv.setItem(GRID_SLOTS[i], entries.get(dataIdx));
            } else {
                inv.setItem(GRID_SLOTS[i], null);
            }
        }

        // Barra inferior (45-53): Navegación, Paginación, Armería, Resource Pack, Cerrar
        inv.setItem(45, PlayerGUI.createGuiItem(Material.ARROW, "&eVolver al Menú Principal",
                List.of("&7Regresa al hub principal de razas.")));

        if (state.page > 0) {
            inv.setItem(47, PlayerGUI.createGuiItem(Material.SPECTRAL_ARROW, "&a◀ Página Anterior",
                    List.of("&7Ir a la página " + state.page + " de " + totalPages)));
        }

        inv.setItem(49, PlayerGUI.createGuiItem(Material.NETHERITE_SWORD, "&6&lCatálogo de Reliquias y Objetos",
                List.of("&7Explora armas, amuletos, coleccionables", "&7y élitros físicos 3D del Resource Pack.")));

        inv.setItem(50, PlayerGUI.createGuiItem(Material.PAINTING, "&a&lInstalar Resource Pack Oficial",
                List.of("&7Descarga gratuita del Pack con texturas reales", "&7y modelos Blockbench 3D de alas y reliquias.")));

        if (state.page + 1 < totalPages) {
            inv.setItem(51, PlayerGUI.createGuiItem(Material.SPECTRAL_ARROW, "&aPágina Siguiente ▶",
                    List.of("&7Ir a la página " + (state.page + 2) + " de " + totalPages)));
        }

        inv.setItem(53, PlayerGUI.createGuiItem(Material.BARRIER, "&c&lCerrar", null));

        player.openInventory(inv);
    }

    private List<ItemStack> buildWingIcons(Player player, PlayerData data, List<WingsManager.WingDefinition> wings,
                                           String activeWings, boolean onlyUnlocked) {
        List<ItemStack> list = new ArrayList<>();
        boolean isAdmin = player.hasPermission("cytricosraces.admin");

        for (WingsManager.WingDefinition def : wings) {
            boolean unlocked = plugin.getWingsManager().isWingUnlocked(player, data, def);
            if (onlyUnlocked && !unlocked) continue;

            boolean equipped = activeWings.equalsIgnoreCase(def.id);
            List<String> lore = new ArrayList<>();
            lore.add("&7" + def.description);
            lore.add("&7Rareza: " + def.rarity.label + " &8| &7Raza Afín: &e" + def.recommendedRace.toUpperCase());
            lore.add("&7Requisito: " + (unlocked ? "&a✔ " + def.unlockNote : "&c✖ " + def.unlockNote));
            lore.add("&8Modelo 3D: &fcytricos:" + def.id + " &7(CMD " + def.customModelData + ")");
            lore.add("");

            if (equipped) {
                lore.add("&a✔ ALAS EQUIPADAS ACTUALMENTE");
                lore.add("&c▶ Clic izquierdo para desequipar.");
            } else if (unlocked) {
                lore.add("&a✔ DISPONIBLE EN TU COLECCIÓN");
                lore.add("&e▶ Clic izquierdo para equipar alas animadas.");
            } else {
                lore.add("&c✖ COSMÉTICO BLOQUEADO");
                if (def.unlockCost > 0 && plugin.getConfig().getBoolean("cosmetics_settings.wings.allow_vault_unlock", true)) {
                    lore.add("&6▶ Clic izquierdo para desbloquear por &e$" + String.format("%.0f", def.unlockCost) + "&6.");
                } else {
                    lore.add("&7Alcanza el &eNivel " + def.requiredLevel + " &7para desbloquear.");
                }
            }
            if (isAdmin) {
                lore.add("&b▶ Clic derecho (Admin): Recibir Élitros 3D físicos.");
            }

            ItemStack icon = new ItemStack(def.iconMaterial);
            ItemMeta meta = icon.getItemMeta();
            if (meta != null) {
                String prefix = equipped ? "&a★ " : (unlocked ? "" : "&8🔒 ");
                meta.displayName(ColorUtils.component(prefix + def.displayName));
                meta.setCustomModelData(def.customModelData);
                meta.lore(ColorUtils.componentList(lore));
                meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS);
                icon.setItemMeta(meta);
            }
            list.add(icon);
        }
        return list;
    }

    private List<ItemStack> buildAuraIcons(Player player, PlayerData data, List<CosmeticsManager.AuraDefinition> auras,
                                           String activeAura, boolean onlyUnlocked) {
        List<ItemStack> list = new ArrayList<>();
        for (CosmeticsManager.AuraDefinition def : auras) {
            boolean unlocked = plugin.getCosmeticsManager().isAuraUnlocked(player, data, def);
            if (onlyUnlocked && !unlocked) continue;

            boolean equipped = activeAura.equalsIgnoreCase(def.id);
            List<String> lore = new ArrayList<>();
            lore.add("&7" + def.description);
            if (!"none".equalsIgnoreCase(def.id)) {
                lore.add("&7Rareza: " + def.rarity.label);
                lore.add("&7Requisito: " + (unlocked
                        ? "&a✔ Desbloqueada"
                        : "&c✖ Nivel " + def.requiredLevel + "+ o $" + String.format("%.0f", def.unlockCost)));
            }
            lore.add("");
            if (equipped) {
                lore.add("&a✔ AURA EQUIPADA ACTUALMENTE");
            } else if (unlocked) {
                lore.add("&e▶ Clic para equipar este efecto orbital.");
            } else {
                lore.add("&6▶ Clic para desbloquear por &e$" + String.format("%.0f", def.unlockCost) + "&6.");
            }

            list.add(PlayerGUI.createGuiItem(def.icon, (equipped ? "&a★ " : (unlocked ? "" : "&8🔒 ")) + def.displayName, lore));
        }
        return list;
    }

    public void handleClick(Player player, int slot, boolean isRightClick) {
        PlayerData data = plugin.getPlayerDataManager().get(player.getUniqueId());
        if (data == null) return;
        ViewState state = viewStates.computeIfAbsent(player.getUniqueId(), k -> new ViewState());

        if (slot == 1) {
            state.tab = Tab.WINGS;
            state.page = 0;
            player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.8f, 1.2f);
            render(player, state);
            return;
        }
        if (slot == 7) {
            state.tab = Tab.AURAS;
            state.page = 0;
            player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.8f, 1.2f);
            render(player, state);
            return;
        }
        if (slot == 3) {
            state.onlyUnlocked = !state.onlyUnlocked;
            state.page = 0;
            player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.8f, 1.0f);
            render(player, state);
            return;
        }
        if (slot == 5) {
            if (state.tab == Tab.WINGS) {
                plugin.getWingsManager().equipCosmeticWings(player, "none");
                ColorUtils.sendMessage(player, "&7Alas cosméticas desactivadas.");
            } else {
                data.setSelectedCosmeticAura("none");
                plugin.getPlayerDataManager().saveToFile(data);
                ColorUtils.sendMessage(player, "&7Aura cosmética desactivada.");
            }
            player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.8f, 0.8f);
            render(player, state);
            return;
        }
        if (slot == 47 && state.page > 0) {
            state.page--;
            player.playSound(player.getLocation(), Sound.ITEM_BOOK_PAGE_TURN, 0.9f, 1.0f);
            render(player, state);
            return;
        }
        if (slot == 51) {
            state.page++;
            player.playSound(player.getLocation(), Sound.ITEM_BOOK_PAGE_TURN, 0.9f, 1.1f);
            render(player, state);
            return;
        }
        if (slot == 49) {
            plugin.getCustomItemsGUI().open(player);
            return;
        }
        if (slot == 50) {
            player.closeInventory();
            plugin.sendConfiguredResourcePack(player);
            return;
        }

        // Verificar si clicó en un slot del grid
        int gridIdx = -1;
        for (int i = 0; i < GRID_SLOTS.length; i++) {
            if (GRID_SLOTS[i] == slot) {
                gridIdx = i;
                break;
            }
        }
        if (gridIdx == -1) return;

        int absoluteIdx = (state.page * GRID_SLOTS.length) + gridIdx;

        if (state.tab == Tab.WINGS) {
            List<WingsManager.WingDefinition> filtered = new ArrayList<>();
            for (WingsManager.WingDefinition w : plugin.getWingsManager().getAllWings()) {
                if (!state.onlyUnlocked || plugin.getWingsManager().isWingUnlocked(player, data, w)) {
                    filtered.add(w);
                }
            }
            if (absoluteIdx >= filtered.size()) return;

            WingsManager.WingDefinition def = filtered.get(absoluteIdx);
            if (isRightClick && player.hasPermission("cytricosraces.admin")) {
                ItemStack elytra = plugin.getWingsManager().createWingElytraItem(def.id);
                if (elytra != null) {
                    plugin.getCustomItemManager().giveItemSafely(player, elytra);
                    player.playSound(player.getLocation(), Sound.ENTITY_ITEM_PICKUP, 1.0f, 1.2f);
                    ColorUtils.sendMessage(player, "&aÉlitros personalizados entregados: " + def.displayName);
                }
                return;
            }

            if (!plugin.getWingsManager().isWingUnlocked(player, data, def)) {
                if (!plugin.getWingsManager().tryUnlockWithVault(player, data, def)) {
                    player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 0.8f, 1.0f);
                    return;
                }
            }

            if (data.getSelectedWings().equalsIgnoreCase(def.id)) {
                plugin.getWingsManager().equipCosmeticWings(player, "none");
                ColorUtils.sendMessage(player, "&7Has retirado tus alas cosméticas.");
            } else {
                plugin.getWingsManager().equipCosmeticWings(player, def.id);
                player.playSound(player.getLocation(), Sound.ENTITY_PHANTOM_FLAP, 1.0f, 1.2f);
                ColorUtils.sendMessage(player, "&aAlas cosméticas animadas equipadas: " + def.displayName);
            }
            render(player, state);
        } else {
            List<CosmeticsManager.AuraDefinition> filtered = new ArrayList<>();
            for (CosmeticsManager.AuraDefinition a : plugin.getCosmeticsManager().getAllAuras()) {
                if (!state.onlyUnlocked || plugin.getCosmeticsManager().isAuraUnlocked(player, data, a)) {
                    filtered.add(a);
                }
            }
            if (absoluteIdx >= filtered.size()) return;

            CosmeticsManager.AuraDefinition def = filtered.get(absoluteIdx);
            if (!plugin.getCosmeticsManager().isAuraUnlocked(player, data, def)) {
                if (!plugin.getCosmeticsManager().tryUnlockAuraWithVault(player, data, def)) {
                    player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 0.8f, 1.0f);
                    return;
                }
            }

            data.setSelectedCosmeticAura(def.id);
            plugin.getPlayerDataManager().saveToFile(data);
            player.playSound(player.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1.0f, 1.2f);
            if (!"none".equalsIgnoreCase(def.id)) {
                player.getWorld().spawnParticle(Particle.GLOW, player.getLocation().add(0, 1.2, 0), 10, 0.4, 0.4, 0.4, 0.05);
                ColorUtils.sendMessage(player, "&aAura cosmética equipada: " + def.displayName);
            } else {
                ColorUtils.sendMessage(player, "&7Aura cosmética desactivada.");
            }
            render(player, state);
        }
    }
}
